# cloudstorage
Repository for handling document storage to cloud with user authentication using openstack swift,nodejs,mysql and reactjs
## If you are here to find code for login forms then head over to updated and recent repo here: [loginforms](https://github.com/codeclassifiers/loginforms)
I created this repository around 3 years back for a final year project. Since then a lot has changed in react ecosystem and also material ui library used in the project. Due to busy schedule I don't have sufficient time to overhaul the project to get it on par with the latest versions of meterial-ui and react.js. If anyone would like to help in updating the project to latest versions then do get in touch with me on [LinkedIn](https://www.linkedin.com/in/saurabh-mhatre) or [Twitter](https://twitter.com/Technoetics1)

